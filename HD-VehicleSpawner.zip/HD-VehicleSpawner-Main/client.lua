local vehSpawnerMenu = nil
local vehSpawnerMenuOpen = false

-- Load NativeUI
local NativeUI = require('NativeUI')
local MenuPool = NativeUI.CreatePool()
vehSpawnerMenu = NativeUI.CreateMenu("Vehicle Spawner", "Choose a vehicle to spawn")
MenuPool:Add(vehSpawnerMenu)

-- Function to spawn a vehicle
function SpawnVehicle(vehicleName)
    local playerPed = GetPlayerPed(-1)
    local pos = GetEntityCoords(playerPed)

    RequestModel(vehicleName)
    while not HasModelLoaded(vehicleName) do
        Wait(500)
    end

    local vehicle = CreateVehicle(vehicleName, pos.x, pos.y, pos.z, GetEntityHeading(playerPed), true, false)
    TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
    SetModelAsNoLongerNeeded(vehicleName)
end

-- Function to add vehicles to the menu
function AddVehicles(menu)
    local vehicles = {
        {label = "Adder", model = "adder"},
        {label = "Zentorno", model = "zentorno"},
        {label = "Buzzard", model = "buzzard"}
    }

    for _, veh in pairs(vehicles) do
        local vehItem = NativeUI.CreateItem(veh.label, "Spawn a " .. veh.label)
        vehItem.Activated = function(sender, item)
            SpawnVehicle(veh.model)
        end
        menu:AddItem(vehItem)
    end
end

AddVehicles(vehSpawnerMenu)
MenuPool:RefreshIndex()

-- Open the menu
function OpenVehSpawnerMenu()
    if vehSpawnerMenuOpen then
        vehSpawnerMenu:Visible(not vehSpawnerMenu:Visible())
    else
        vehSpawnerMenuOpen = true
        vehSpawnerMenu:Visible(true)
    end
end

-- Key control
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        MenuPool:ProcessMenus()
        if IsControlJustPressed(1, 51) then -- Change the key to whatever you want (51 is E by default)
            OpenVehSpawnerMenu()
        end
    end
end)
